# scpark-network

An open pipeline for studying whether micro-geographic proximity to a science
park is associated with an institution's position in a research collaboration
network. It extracts bibliometric records for an OpenAlex topic, geocodes the
raw affiliation strings behind those records, classifies each institution's
micro-geographic proximity to a science park using a Wikidata-derived registry
cross-validated against OpenStreetMap boundaries and density features, builds
institution-level co-affiliation networks under two node-identity schemes
(raw-string and entity-resolved), and runs a battery of robustness checks
covering distance thresholds, institutional size and productivity controls,
permutation null models, multiple-comparison correction and equivalence testing.
Every step reads and writes plain CSV or JSON, so any stage can be inspected,
replaced or restarted independently.

## Requirements

Python 3.9 or newer.

```bash
pip install -r requirements.txt
```

The scripts depend only on `requests`, `pandas`, `numpy`, `networkx`,
`statsmodels` and `scipy`.

## Pipeline order

Run the scripts from the directory holding the data files; each one reads the
outputs of the previous steps from the current working directory.

**Extraction and classification (`pipeline/`)**

1. `01_fetch_openalex.py` — retrieves all works for the chosen OpenAlex topic and
   writes `affil_full.csv` (author-affiliation records) and `addr_uniq_full.csv`
   (unique affiliation strings to geocode). Minutes.
2. `01b_fetch_openalex_cart.py` — the same extraction for the CAR-T replication
   topic, capped at 5,000 works. Run it in a separate directory: it writes the
   same filenames on purpose so steps 02 and 05-09 need no changes.
3. `02_geocode_and_enrich.py` — geocodes every unique address through Nominatim
   and attaches the OSM park polygon test and density/accessibility features,
   producing `geocoded.csv` and `enriched.csv`. **Slow and rate-limited:**
   Nominatim permits about one request per second, so a full run takes days. It
   is interruptible — the caches (`geo_cache.json`, `overpass_cache.json`) are
   flushed continuously and re-running resumes where it stopped.
4. `03_fetch_wikidata_parks.py` — builds the science-park registry from Wikidata
   and writes `parks_wikidata.csv`. Minutes. A copy already ships in `data/`, so
   this only needs running to refresh the registry.
5. `04_fetch_park_polygons.py` — fetches exact boundaries for the registry
   entries that link an OSM relation, writing `park_polygons.json`. Minutes; a
   copy also ships in `data/`.
6. `05_match_parks_distance.py` — matches every institution coordinate to its
   nearest registry park and applies the distance threshold, writing
   `park_matches.csv`. Seconds, entirely offline.
7. `06_apply_polygon_refinement.py` — refines that classification with the exact
   boundaries and adds `in_park_polygon_precise` and `in_park_best_guess` to
   `park_matches.csv`. Seconds.
8. `07_merge_method_a_b.py` — merges the registry and OSM classifications into
   `combined.csv` and reports their agreement rate. Seconds.
9. `08_build_entity_resolved_network.py` — builds the network whose nodes are
   OpenAlex's disambiguated institution names, writing `std_nodes.json` and
   `std_edges.json`. Minutes to hours, dominated by community detection.
10. `09_build_naive_network.py` — builds the raw-string counterpart, writing
    `nodes.json` and `edges.json`. Usually the slowest step of the pipeline: this
    network has several times more nodes than the entity-resolved one.

**Analysis (`analysis/`)**

11. `10_robustness_checks.py` — the main battery: negative binomial diagnostics
    against Poisson, TOST equivalence, VIF, geocoding missingness by country,
    distance-threshold sensitivity, leave-one-park-out, size control, community
    composition, weighted vs unweighted degree, a label-permutation null model
    and Holm-Bonferroni correction. Prints everything; writes nothing.
12. `10b_supplementary_robustness_checks.py` — betweenness alongside degree for
    the threshold and leave-one-park-out analyses, exclusion of two
    false-positive registry parks, and exclusion of hyper-authorship papers with
    the network rebuilt.
13. `11_institution_size_control.py` — refits the size-control model with the
    dispersion parameter estimated by maximum likelihood and recomputes VIF on
    the five-predictor specification.
14. `12_productivity_control_robustness.py` — stress-tests that model's park
    coefficient with threshold sensitivity, a permutation test that refits the
    full model on each permutation, and Holm-Bonferroni correction. The
    permutation test is the slow part (one model fit per permutation).
15. `13_fetch_density_5000m.py` — retrieves the university and research-institute
    count within 5,000 m of each institution from Overpass. **Slow:** hours, but
    resumable — progress is cached after every batch and re-running continues.
16. `14_refetch_density_2000m.py` — the same retrieval at 2,000 m, so both radii
    come from one OpenStreetMap snapshot. Also hours and resumable.
17. `15_compute_reported_statistics.py` — recomputes every statistic reported in
    the article from the current data, in the order the article presents them.

Steps 11 to 14 must be run from the same directory as `10_robustness_checks.py`:
scripts 11 and 12 load it with `importlib` (a module name starting with a digit
cannot be imported with a normal `import` statement).

## Configuration

- **`MAILTO`** — set this module-level constant in every script that contacts an
  external service (`01`, `01b`, `02`, `03`, `04`, `13`, `14`). OpenAlex,
  Nominatim and Overpass all ask for a contact address so they can reach the
  operator of a misbehaving script; running with the placeholder is impolite and
  may get you rate-limited or blocked.
- **Topic** — `TOPIC_ID` in `01_fetch_openalex.py` selects the OpenAlex topic,
  and `max_records` caps the extraction. The publication-year window is a
  parameter of `fetch_works_by_topic()`.
- **Distance thresholds** — `MATCH_RADIUS_M` in `05_match_parks_distance.py` sets
  the primary treatment radius (2,000 m). The robustness scripts sweep
  500/1,000/2,000/3,000/5,000 m through the `radii_m` argument; the density
  search radius in `02_geocode_and_enrich.py` (`radius_m`) is set to match the
  primary threshold, and station/junction searches use twice that radius.
- **Equivalence bounds** — the TOST bounds default to IRR 0.80-1.25 and are set
  where `run_tost()` is called.
- **Retrieval date** — retrieve all density covariates in a single session.
  OpenStreetMap coverage grows over time, so counts taken weeks apart are not
  comparable, and mixing retrieval dates across radii changes the results. Both
  density scripts record the UTC timestamp and the Overpass instance of every
  batch in a `*_provenance.json` file; quote those when describing the data.

## Data

`data/` holds the two small registry files the pipeline depends on:

- `parks_wikidata.csv` — the science-park registry from Wikidata (id,
  coordinates, OSM relation id where available, name, country), the output of
  step 03.
- `park_polygons.json` — exact boundaries for the registry entries that link an
  OSM relation, as lists of closed rings, the output of step 04.

See `data/README.md` for details.

Large intermediate files are not in this repository: the raw affiliation
extraction, the geocoding and Overpass caches, the classification tables and the
network JSON files together run to hundreds of megabytes. They are archived
separately (see the Zenodo release below) and can be regenerated by running the
pipeline from step 01, though geocoding a large topic takes days.

## Citation

If you use this code, please cite the article:

> [Author(s)] ([Year]). [Article title]. *[Journal]*, [volume(issue)], [pages].
> https://doi.org/[DOI]

Archived release: [Zenodo DOI]

## License

MIT — see `LICENSE`.
