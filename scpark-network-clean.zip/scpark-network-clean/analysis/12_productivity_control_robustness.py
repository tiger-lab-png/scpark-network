"""
Stress-test the park coefficient of the productivity-control model.

Reads:  affil.csv or affil_full.csv, park_matches.csv, combined.csv,
        std_nodes.json, and nodes.json when available.
Writes: nothing; results are printed.

The specification refitted in 11_institution_size_control.py is subjected to the
same three checks applied to the main result:
  1. distance-threshold sensitivity from 500 m to 5,000 m, to see whether the
     coefficient depends on one particular threshold;
  2. a label-permutation test that refits the full negative binomial model on
     every permutation, since a difference-in-means permutation would not hold
     the covariates constant;
  3. Holm-Bonferroni correction including this model alongside the others.

Run this from the same directory as 10_robustness_checks.py, which is loaded
with importlib because a module name beginning with a digit cannot be imported
normally. Check 2 is the slow part: n_perm model fits, a few minutes at this
sample size; lower n_perm for a quicker, coarser answer.
"""

import importlib
import json
import math
import os
import warnings

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

_robustness = importlib.import_module("10_robustness_checks")
build_std_lookup = _robustness.build_std_lookup
build_regression_df = _robustness.build_regression_df
holm_bonferroni = _robustness.holm_bonferroni

warnings.filterwarnings("ignore")

FORMULA_SIZE = "degree ~ in_science_park + log_univ + log_station + log_junction + log_papers"


def _load_affil_csv():
    """Accept either filename so the same script serves both dataset sizes."""
    for candidate in ("affil.csv", "affil_full.csv"):
        if os.path.exists(candidate):
            print(f"reading {candidate}")
            return pd.read_csv(candidate)
    raise FileNotFoundError("neither affil.csv nor affil_full.csv found.")


def fit_size_control_model(df, formula=FORMULA_SIZE):
    """Same specification as 11_institution_size_control.py: alpha estimated by
    MLE, not the GLM family's fixed alpha=1. The test only means something if it
    uses the identical specification whose coefficient is under scrutiny."""
    return smf.negativebinomial(formula, data=df).fit(disp=0)


# ---------- check 1: threshold sensitivity of the productivity-control model ----------

def threshold_sensitivity_size_control(df_affil, df_park, df_combined, nodes, radii_m):
    print("=" * 70)
    print("[check 1] distance-threshold sensitivity of the productivity-control model")
    print("=" * 70)
    results = []
    for radius in radii_m:
        std_lookup = build_std_lookup(df_affil, df_park, df_combined, match_radius_m=radius)
        df = build_regression_df(nodes, std_lookup)
        n_park = df["in_science_park"].sum()
        if n_park < 5:
            print(f"threshold {radius} m: only {n_park} park institutions, skipped")
            continue
        try:
            model = fit_size_control_model(df)
        except Exception as e:
            print(f"threshold {radius} m: model did not converge ({e}), skipped")
            continue
        coef = model.params["in_science_park"]
        p = model.pvalues["in_science_park"]
        irr = math.exp(coef)
        ci = model.conf_int().loc["in_science_park"]
        print(f"threshold {radius} m: n_park={int(n_park)}, IRR={irr:.3f}, "
              f"95% CI=[{math.exp(ci[0]):.3f}, {math.exp(ci[1]):.3f}], p={p:.4g}"
              f"{'  <- significant' if p < 0.05 else ''}")
        results.append({"radius_m": radius, "n_park": int(n_park), "irr": irr, "p": p})
    return pd.DataFrame(results)


# ---------- check 2: label permutation with a full refit each time ----------

def null_model_regression_coefficient(df, formula=FORMULA_SIZE, n_perm=1000, seed=42):
    """
    Hold degree and all covariates fixed, reassign the in_science_park label at
    random (keeping the number of park institutions), refit the full negative
    binomial model and record the new coefficient. The permutation p value is the
    share of permutations whose |coefficient| reaches the observed |coefficient|.

    Refitting every time is what makes this a test of the coefficient net of the
    covariates, rather than of a raw group difference; it is correspondingly
    slower than the simple permutation test in 10_robustness_checks.py.
    """
    print("\n" + "=" * 70)
    print(f"[check 2] label-permutation test for the productivity-control model "
          f"({n_perm} permutations, each a full model refit; this takes a while)")
    print("=" * 70)

    observed_model = fit_size_control_model(df)
    observed_coef = observed_model.params["in_science_park"]
    print(f"observed in_science_park coefficient = {observed_coef:.4f} "
          f"(IRR = {math.exp(observed_coef):.3f}; should match the value printed by "
          f"11_institution_size_control.py)")

    rng = np.random.default_rng(seed)
    n = len(df)
    n_park = int(df["in_science_park"].sum())
    base = df.drop(columns=["in_science_park"]).copy()

    perm_coefs = []
    n_failed = 0
    count_ge = 0

    for i in range(n_perm):
        perm_labels = np.zeros(n, dtype=int)
        park_idx = rng.choice(n, size=n_park, replace=False)
        perm_labels[park_idx] = 1
        df_perm = base.copy()
        df_perm["in_science_park"] = perm_labels
        try:
            m = smf.negativebinomial(formula, data=df_perm).fit(disp=0, maxiter=100)
            c = m.params["in_science_park"]
        except Exception:
            n_failed += 1
            continue
        perm_coefs.append(c)
        if abs(c) >= abs(observed_coef):
            count_ge += 1

        if (i + 1) % 100 == 0:
            print(f"  {i + 1}/{n_perm} done ({n_failed} non-converged, skipped)")

    n_valid = len(perm_coefs)
    p_perm = count_ge / n_valid if n_valid else float("nan")
    perm_coefs = np.array(perm_coefs)
    print(f"\npermutation p ({n_valid} valid permutations, two-sided) = {p_perm:.4f} "
          f"({n_failed} non-converged fits excluded from the denominator)")
    print(f"mean/sd of the coefficient under random labelling = {perm_coefs.mean():.4f} / {perm_coefs.std():.4f} "
          f"(a mean near zero is the expected sanity check)")
    return p_perm, observed_model


if __name__ == "__main__":
    df_affil = _load_affil_csv()
    df_park = pd.read_csv("park_matches.csv")
    df_combined = pd.read_csv("combined.csv")
    nodes = json.load(open("std_nodes.json", encoding="utf-8"))

    std_lookup = build_std_lookup(df_affil, df_park, df_combined, match_radius_m=2000)
    df = build_regression_df(nodes, std_lookup)
    print(f"regression sample: {len(df)} standardised institutions "
          f"({int(df['in_science_park'].sum())} in parks)\n")

    threshold_df = threshold_sensitivity_size_control(
        df_affil, df_park, df_combined, nodes, radii_m=[500, 1000, 2000, 3000, 5000]
    )

    p_perm, observed_model = null_model_regression_coefficient(df, n_perm=1000)

    # ---------- check 3: Holm-Bonferroni including the productivity-control model ----------
    print("\n" + "=" * 70)
    print("[check 3] Holm-Bonferroni including the productivity-control model")
    print("=" * 70)

    # As in 10_robustness_checks.py, every p value is recomputed from the current
    # data; the third term is the model under scrutiny here.
    park_deg_er = df.loc[df["in_science_park"] == 1, "degree"]
    nonpark_deg_er = df.loc[df["in_science_park"] == 0, "degree"]
    _, p_entity_resolved = stats.mannwhitneyu(park_deg_er, nonpark_deg_er, alternative="two-sided")

    base_model = smf.negativebinomial(
        "degree ~ in_science_park + log_univ + log_station + log_junction", data=df
    ).fit(disp=0)

    pvalue_dict = {
        "entity-resolved degree Mann-Whitney": p_entity_resolved,
        "NB regression, no productivity control": base_model.pvalues["in_science_park"],
        "NB regression, WITH productivity control": observed_model.pvalues["in_science_park"],
    }

    if os.path.exists("nodes.json"):
        naive_nodes = json.load(open("nodes.json", encoding="utf-8"))
        naive_park = [n["degree"] for n in naive_nodes if n.get("in_science_park")]
        naive_nonpark = [n["degree"] for n in naive_nodes if not n.get("in_science_park")]
        _, p_naive = stats.mannwhitneyu(naive_park, naive_nonpark, alternative="two-sided")
        pvalue_dict["naive degree Mann-Whitney"] = p_naive
    else:
        print("nodes.json not found; the naive-network term is omitted (the other terms are unaffected).")

    holm_bonferroni(pvalue_dict)

    print("\nDone.")
