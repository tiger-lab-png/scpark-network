"""
Geocode affiliation strings and attach micro-geographic features (methods A/B).

Reads:  addr_uniq_full.csv (unique raw affiliation strings from step 01).
Writes: geocoded.csv  address -> latitude/longitude;
        enriched.csv  the same rows plus, per coordinate, whether the point
                      falls inside an OSM area whose name matches a science-park
                      keyword (method A, point-in-polygon via Overpass `is_in`)
                      and, as a fallback, density/accessibility features
                      (method B: universities and research institutes within
                      radius_m, distance to the nearest railway station and
                      motorway junction).
        geo_cache.json / overpass_cache.json are written continuously, so the
        script can be interrupted with Ctrl+C and resumed by re-running it.
Set before running: MAILTO, PARK_KEYWORDS if another language is needed, and
radius_m in classify_location_combined (default 2,000 m).
Nominatim allows roughly one request per second, so a full run takes days.
"""

import json
import math
import os
import re
import time

import pandas as pd
import requests

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"

# Public Overpass instances differ in capacity and uptime; several are listed so
# that a failing or throttled one can be skipped (see _ordered_endpoints).
OVERPASS_ENDPOINTS = [
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
    "https://overpass-api.de/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
    "https://lz4.overpass-api.de/api/interpreter",
    "https://z.overpass-api.de/api/interpreter",
]

# OpenAlex, Nominatim and Overpass all ask for a contact address so they can
# reach the operator of a script that misbehaves.
MAILTO = "your-email@example.com"

# Nominatim's usage policy requires an identifiable User-Agent with a contact.
HEADERS = {
    "User-Agent": f"micro-geo-innovation-mapper/0.1 ({MAILTO})"
}

GEOCODE_CACHE_FILE = "geo_cache.json"  # short names keep Windows paths under 260 chars
NOMINATIM_MIN_INTERVAL = 1.1  # seconds; slightly above the 1 req/s policy limit

# Name fragments that identify a science park / innovation district. Extend this
# list for other languages or regional naming conventions.
PARK_KEYWORDS = [
    "science park", "technology park", "tech park", "innovation district",
    "innovation park", "research park", "high-tech zone", "hi-tech zone",
    "科學園區", "科技園區", "產業園區", "創新園區", "研究園區",
]


# ---------- cache helpers ----------

def load_cache(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_cache(cache, path):
    """
    Write to a temporary file and swap it in with os.replace(), which is atomic
    on a single filesystem. An unattended run that is killed mid-write then
    leaves the previous complete cache intact instead of a truncated JSON file.
    """
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


# ---------- geocoding ----------

# Fragments that mark the institution level of an address rather than a
# department or laboratory. The *last* match is used as the cut point, which
# drops leading departmental detail while keeping the institution name itself.
INSTITUTION_KEYWORDS = re.compile(
    r'\b(university|institute|college|hospital|school|center|centre|'
    r'corp|inc|ltd|laboratory|lab|academy|foundation|clinic|company)\b',
    re.IGNORECASE,
)


def clean_address_variants(address):
    """
    Produce progressively simpler query strings for one raw affiliation.

    Raw affiliation strings often carry departmental detail, e-mail addresses and
    superscript footnote digits glued to the first word, which Nominatim's free
    text parser frequently fails on even when the underlying place is known.
    The variants are tried in order and the first hit wins:
      1. the string as given;
      2. without a leading footnote digit ("6Department..." -> "Department...");
      3. without e-mail addresses / "Electronic address:" fragments;
      4. from the last comma-separated part containing an institution keyword to
         the end, which keeps the institution name — cutting straight down to
         "City, Country" would collapse the coordinate to a city centroid and
         destroy the campus-level precision this study needs;
      5. last resort: the final 3 and then final 2 comma-separated parts.
    """
    variants = [address]

    no_footnote = re.sub(r'^\d+(?=[A-Za-z])', '', address).strip()
    if no_footnote and no_footnote != address:
        variants.append(no_footnote)

    no_email = re.sub(r'Electronic address:\s*\S+', '', no_footnote, flags=re.IGNORECASE)
    no_email = re.sub(r'\S+@\S+', '', no_email).strip(' .;,')
    if no_email and no_email != no_footnote:
        variants.append(no_email)

    parts = [p.strip() for p in no_email.split(',') if p.strip()]

    inst_idx = None
    for i, p in enumerate(parts):
        if INSTITUTION_KEYWORDS.search(p):
            inst_idx = i  # keep the last match: the institution can appear late
    if inst_idx is not None and inst_idx > 0:
        variants.append(', '.join(parts[inst_idx:]))

    for n in (3, 2):
        if len(parts) > n:
            variants.append(', '.join(parts[-n:]))

    seen = set()
    unique_variants = []
    for v in variants:
        if v and v not in seen:
            seen.add(v)
            unique_variants.append(v)
    return unique_variants


def _nominatim_call(query_text, max_retries=3):
    """
    Query Nominatim once and return (results, network_ok).

    network_ok=False means the request itself kept failing, which the caller must
    keep separate from a successful lookup that legitimately found nothing.
    """
    params = {"q": query_text, "format": "jsonv2", "limit": 1}
    for attempt in range(max_retries):
        try:
            resp = requests.get(NOMINATIM_URL, params=params, headers=HEADERS, timeout=20)
            resp.raise_for_status()
            return resp.json(), True
        except Exception as e:
            wait = 2 ** attempt  # exponential backoff: 1s, 2s, 4s
            print(f"[geocode retry {attempt + 1}/{max_retries}] {query_text[:60]}...: {e}")
            time.sleep(wait)
    return None, False


def geocode_address(address, cache, max_retries=3):
    """
    Resolve one address to (lat, lon), consulting the local cache first and
    writing every answer back immediately.

    A transient network failure is *not* cached, so a re-run retries it; only a
    successful call that returned no candidate is cached as a genuine miss. The
    simplified variants from clean_address_variants() are tried in order, and the
    original address is always used as the cache key regardless of which variant
    produced the hit.
    """
    if address in cache:
        return cache[address]

    variants = clean_address_variants(address)

    for variant_idx, variant in enumerate(variants):
        results, network_ok = _nominatim_call(variant, max_retries=max_retries)

        if not network_ok:
            # Network-level failure, not a miss: give up on this address without
            # caching so the next run tries all variants again.
            print(f"[geocode skipped, will be retried on the next run] {address[:60]}...")
            time.sleep(NOMINATIM_MIN_INTERVAL)
            return [None, None]

        time.sleep(NOMINATIM_MIN_INTERVAL)  # throttle every HTTP call, not every address

        if results:
            lat, lon = float(results[0]["lat"]), float(results[0]["lon"])
            if variant_idx > 0:
                print(f"[geocode hit after simplification] resolved using the "
                      f"variant \"{variant[:60]}\"")
            cache[address] = [lat, lon]
            save_cache(cache, GEOCODE_CACHE_FILE)
            return [lat, lon]

    # Every variant returned an empty result: cache it as a genuine miss.
    cache[address] = [None, None]
    save_cache(cache, GEOCODE_CACHE_FILE)
    return [None, None]


def geocode_all(addresses, cache_path=GEOCODE_CACHE_FILE, failed_log_path="geo_failed.txt"):
    """
    Geocode every address, resumably: the cache is flushed after each address, so
    re-running the script skips everything already resolved and effectively
    continues where it stopped.

    Addresses that still failed at the network level during this run are listed
    in geo_failed.txt; they are not cached and will be retried automatically.
    """
    cache = load_cache(cache_path)
    records = []
    start_time = time.time()
    failed_this_run = []
    consecutive_empty = 0  # a long run of misses usually means soft throttling

    try:
        for i, addr in enumerate(addresses):
            was_cached = addr in cache
            lat, lon = geocode_address(addr, cache)

            if not was_cached and lat is None and lon is None:
                # counted only for addresses actually processed in this run
                failed_this_run.append(addr)
                consecutive_empty += 1
                if consecutive_empty >= 15:
                    print(f"\n{consecutive_empty} consecutive addresses returned no "
                          f"result even after simplification, which is more likely "
                          f"to be soft throttling than coincidence. Pausing for 60 "
                          f"seconds; if it continues, stop and check a few "
                          f"addresses by hand.\n")
                    time.sleep(60)
                    consecutive_empty = 0
            elif not was_cached:
                consecutive_empty = 0

            records.append({"Raw_Affiliation": addr, "Latitude": lat, "Longitude": lon})

            if (i + 1) % 50 == 0:
                elapsed = time.time() - start_time
                rate = (i + 1) / elapsed  # addresses per second
                remaining = (len(addresses) - (i + 1)) / rate if rate > 0 else float("nan")
                print(f"geocoded {i + 1}/{len(addresses)}  "
                      f"estimated time remaining: {remaining / 60:.1f} min")

    except KeyboardInterrupt:
        print(f"\nInterrupted: {len(records)}/{len(addresses)} done. Everything "
              f"resolved so far is in {cache_path}; re-running this script "
              f"continues from here.")
        raise

    if failed_this_run:
        with open(failed_log_path, "w", encoding="utf-8") as f:
            f.write("\n".join(failed_this_run))
        print(f"\n{len(failed_this_run)} addresses still failed after 3 retries; "
              f"the list is in {failed_log_path}. They were not cached and will "
              f"be retried on the next run.")

    return pd.DataFrame(records)


# ---------- Overpass querying, retries and coordinate-level caching ----------

OVERPASS_CACHE_FILE = "overpass_cache.json"
OVERPASS_MIN_INTERVAL = 3.0  # public instances throttle aggressively at higher rates


def _coord_key(lat, lon, precision=4):
    """Round to 4 decimals (~11 m) so departments on one campus share a cache entry."""
    return f"{round(lat, precision)}_{round(lon, precision)}"


OVERPASS_ENDPOINT_COOLDOWN_SECONDS = 300  # skip an endpoint for 5 min after a failure
_endpoint_cooldown_until = {}  # endpoint -> expiry timestamp, in memory for this run only


def _ordered_endpoints():
    """
    Put endpoints that recently failed at the back of the queue.

    This is a preference, not an exclusion: if every endpoint is cooling down the
    whole list is still tried. Without this memory each new coordinate would pay
    the cost of timing out on the same dead endpoints again, which dominates the
    runtime when a popular mirror is down.
    """
    now = time.time()
    healthy = [e for e in OVERPASS_ENDPOINTS if _endpoint_cooldown_until.get(e, 0) <= now]
    cooling = [e for e in OVERPASS_ENDPOINTS if _endpoint_cooldown_until.get(e, 0) > now]
    return healthy + cooling


def _mark_endpoint_failed(endpoint):
    _endpoint_cooldown_until[endpoint] = time.time() + OVERPASS_ENDPOINT_COOLDOWN_SECONDS


def overpass_query(query, max_node_failures=4, max_rate_limit_waits=2):
    """
    Send one query to Overpass, distinguishing two kinds of failure:

    - 429 (Too Many Requests): the endpoint is alive and only wants a slower
      pace, so wait and retry the *same* endpoint rather than paying a 30 s
      timeout on a possibly dead one. After max_rate_limit_waits rounds the
      endpoint is abandoned so the remaining mirrors get a turn.
    - anything else (timeouts, 406, ...): the endpoint itself is the problem, so
      move on and put it into cooldown (see _ordered_endpoints).

    max_node_failures is a fixed cap rather than the pool size, which keeps the
    worst-case wait for a single query predictable as more mirrors are added; the
    extra mirrors serve to spread load across queries.

    Returns the element list, or None if every attempt failed — the caller must
    not treat None as "nothing found".
    """
    endpoints = _ordered_endpoints()

    for node_attempt in range(max_node_failures):
        endpoint = endpoints[node_attempt % len(endpoints)]

        for rate_limit_attempt in range(max_rate_limit_waits):
            try:
                resp = requests.post(endpoint, data={"data": query}, headers=HEADERS, timeout=30)
            except Exception as e:
                print(f"[overpass endpoint error {node_attempt + 1}/{max_node_failures}, switching] {endpoint}: {e}")
                _mark_endpoint_failed(endpoint)
                break  # not a rate-limit problem, try another endpoint

            if resp.status_code == 429:
                retry_after = resp.headers.get("Retry-After")
                wait = float(retry_after) if retry_after else 15
                print(f"[overpass 429, {endpoint} busy, waiting {wait} s and retrying "
                      f"the same endpoint ({rate_limit_attempt + 1}/{max_rate_limit_waits})]")
                time.sleep(wait)
                continue  # same endpoint, does not count as a node failure

            try:
                resp.raise_for_status()
                return resp.json().get("elements", [])
            except Exception as e:
                print(f"[overpass endpoint error {node_attempt + 1}/{max_node_failures}, switching] {endpoint}: {e}")
                _mark_endpoint_failed(endpoint)
                break
        else:
            # still rate limited after max_rate_limit_waits rounds
            print(f"[overpass {endpoint} rate limited too often, giving up on it]")
            _mark_endpoint_failed(endpoint)

        time.sleep(2)  # brief pause before switching endpoint

    return None


def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  # metres
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def classify_location_combined(lat, lon, radius_m=2000):
    """
    Run method A (is_in park polygon) and method B (density/accessibility) as a
    single Overpass query, halving the request count against a rate-limited
    public service.

    `is_in` is used rather than `around` because only `is_in` answers "is this
    point inside the area"; `around` merely finds nearby features. The two result
    sets cannot be confused: park areas are recognised by a keyword in `name`,
    density features by their amenity/railway/highway tags.

    Returns None if the query failed after retries, which is not the same as a
    successful query that found nothing.
    """
    query = f"""
    [out:json][timeout:30];
    is_in({lat},{lon})->.park;
    (way(pivot.park); relation(pivot.park);) -> .parkAreas;
    .parkAreas out tags;
    (
      node["amenity"~"university|research_institute"](around:{radius_m},{lat},{lon});
      way["amenity"~"university|research_institute"](around:{radius_m},{lat},{lon});
      node["railway"="station"](around:{radius_m * 2},{lat},{lon});
      node["highway"="motorway_junction"](around:{radius_m * 2},{lat},{lon});
    ) -> .nearby;
    .nearby out center;
    """
    elements = overpass_query(query)
    if elements is None:
        return None

    in_park, park_name = False, None
    univ_count = 0
    station_dists, junction_dists = [], []

    for el in elements:
        tags = el.get("tags", {})
        name = (tags.get("name") or "").lower()
        if not in_park and any(kw in name for kw in PARK_KEYWORDS):
            in_park, park_name = True, tags.get("name")

        elat = el.get("lat") or (el.get("center") or {}).get("lat")
        elon = el.get("lon") or (el.get("center") or {}).get("lon")
        if elat is not None and elon is not None:
            d = haversine(lat, lon, elat, elon)
            # the loose regex above can match other amenity values, so count only
            # exact matches here
            if tags.get("amenity") in ("university", "research_institute"):
                univ_count += 1
            if tags.get("railway") == "station":
                station_dists.append(d)
            if tags.get("highway") == "motorway_junction":
                junction_dists.append(d)

    return {
        "in_science_park": in_park,
        "park_name": park_name if in_park else None,
        "univ_research_count": univ_count,
        "nearest_station_m": min(station_dists) if station_dists else None,
        "nearest_junction_m": min(junction_dists) if junction_dists else None,
        "method_used": "A_polygon" if in_park else "B_density_fallback",
    }


# ---------- hybrid: A first, fall back to B when no polygon is found ----------

def classify_location(lat, lon, cache):
    """
    Classify one coordinate and cache the result, so several institutions sharing
    a campus cost a single Overpass request.

    Missing coordinates are detected with pd.isna(): a DataFrame column holding
    both floats and None is cast to float64, turning None into NaN, and
    `NaN is None` is False — the check has to be pd.isna() or invalid queries get
    sent with NaN coordinates.
    """
    if pd.isna(lat) or pd.isna(lon):
        return {
            "in_science_park": None, "park_name": None,
            "univ_research_count": None, "nearest_station_m": None,
            "nearest_junction_m": None, "method_used": "no_coordinates",
        }

    key = _coord_key(lat, lon)
    if key in cache:
        return cache[key]

    result = classify_location_combined(lat, lon)
    time.sleep(OVERPASS_MIN_INTERVAL)

    if result is None:
        # Query failure, kept out of the cache so the next run retries it and
        # kept distinct from a valid "not inside any park" answer.
        return {
            "in_science_park": None, "park_name": None,
            "univ_research_count": None, "nearest_station_m": None,
            "nearest_junction_m": None, "method_used": "overpass_failed",
        }

    cache[key] = result
    save_cache(cache, OVERPASS_CACHE_FILE)
    return result


def enrich_addresses(df_geocoded, cache_path=OVERPASS_CACHE_FILE):
    """
    Attach the hybrid A/B classification to every geocoded address. Like
    geocode_all() this is interruptible and resumable through the cache.
    """
    cache = load_cache(cache_path)

    # The real workload is the number of distinct coordinates, not the number of
    # addresses: departments of one university share a campus coordinate.
    valid_coords = df_geocoded.dropna(subset=["Latitude", "Longitude"])
    unique_keys = {_coord_key(r.Latitude, r.Longitude) for r in valid_coords.itertuples()}
    already_done = sum(1 for k in unique_keys if k in cache)
    print(f"{len(df_geocoded)} addresses, {len(valid_coords)} with valid coordinates, "
          f"{len(unique_keys)} distinct coordinates to query "
          f"({already_done} already cached, {len(unique_keys) - already_done} remaining)")

    feature_rows = []
    start_time = time.time()

    try:
        for i, row in df_geocoded.iterrows():
            feats = classify_location(row["Latitude"], row["Longitude"], cache)
            feature_rows.append(feats)

            if (i + 1) % 20 == 0:
                elapsed = time.time() - start_time
                rate = (i + 1) / elapsed
                remaining = (len(df_geocoded) - (i + 1)) / rate if rate > 0 else float("nan")
                print(f"feature extraction {i + 1}/{len(df_geocoded)}  "
                      f"estimated time remaining: {remaining / 60:.1f} min")

    except KeyboardInterrupt:
        print(f"\nInterrupted: {len(feature_rows)}/{len(df_geocoded)} done. The "
              f"coordinate cache is in {cache_path}; re-running skips everything "
              f"already queried.")
        raise

    df_features = pd.DataFrame(feature_rows)
    return pd.concat([df_geocoded.reset_index(drop=True), df_features], axis=1)


if __name__ == "__main__":
    addr_df = pd.read_csv("addr_uniq_full.csv")
    addresses = addr_df["Raw_Affiliation"].dropna().tolist()

    print(f"{len(addresses)} addresses to process (Nominatim allows ~1 req/s)...")
    df_geocoded = geocode_all(addresses)
    df_geocoded.to_csv("geocoded.csv", index=False, encoding="utf-8-sig")

    df_enriched = enrich_addresses(df_geocoded)
    df_enriched.to_csv("enriched.csv", index=False, encoding="utf-8-sig")

    hit_a = (df_enriched["method_used"] == "A_polygon").sum()
    hit_b = (df_enriched["method_used"] == "B_density_fallback").sum()
    no_coord = (df_enriched["method_used"] == "no_coordinates").sum()
    overpass_failed = (df_enriched["method_used"] == "overpass_failed").sum()
    print(f"method A hits (inside an OSM park polygon): {hit_a}")
    print(f"method B fallback (density features): {hit_b}")
    print(f"no coordinates, not classifiable: {no_coord}")
    print(f"coordinates present but Overpass query failed (retry by re-running): {overpass_failed}")
